package com.usa.ciclo3.ciclo3.cruderepository;

import com.usa.ciclo3.ciclo3.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> {
}
